create
    definer = root@`%` procedure sp_charge_manifest4meter()
BEGIN
	/*
	* 房间表计收费清单生成，针对基于wg_meter_reading_logged作为单价收费的清单类型
	* author: 龙光磊
	* 2017-5-17
	*/

	#收费设置的字段
	DECLARE s_id VARCHAR(64) DEFAULT NULL;						#id
	DECLARE s_price decimal(10,4) DEFAULT NULL;				#单位面积单价
	DECLARE s_charge_way varchar(50) DEFAULT NULL;		#收费方式（1=周期性，2=临时性）
	DECLARE s_billing_unit varchar(50) DEFAULT NULL;	#计费单位(1=日，2=月，3=年)
	DECLARE s_billing_cycle varchar(50) DEFAULT NULL;	#计费周期数
	DECLARE s_precision_ decimal(10,4) DEFAULT NULL;	#计费精度
	DECLARE s_goldrate decimal(10,4) DEFAULT NULL;		#滞纳金率
	DECLARE s_charge_bdate timestamp DEFAULT NULL;		#收费开始日期
	DECLARE s_charge_edate timestamp DEFAULT NULL;		#收费结束日期
	DECLARE s_covered_area double(8,2) DEFAULT NULL;	#建筑面积

	#收费清单的字段
  DECLARE m_start_date date DEFAULT NULL; 							# '开始时间';
  DECLARE m_end_date date DEFAULT NULL; 								# '结束时间';
  DECLARE m_count decimal(7,2) DEFAULT NULL; 						# '数量';
  DECLARE m_unit_price decimal(7,2) DEFAULT NULL; 			# '单价';
  DECLARE m_override decimal(7,2) DEFAULT NULL;					# '倍率';
  DECLARE m_amount decimal(7,2) DEFAULT NULL; 					# '应收金额';
  DECLARE m_amount_overdue decimal(7,2) DEFAULT NULL;		# '滞纳金';
  DECLARE m_amount_total decimal(7,2) DEFAULT NULL; 		# '应收合计';
  DECLARE m_extend_charge_set_id VARCHAR(64) DEFAULT NULL; 		# '应收合计';
	
	#临时变量
	DECLARE curret_time DATE DEFAULT CURRENT_TIMESTAMP; #当前系统时间
	DECLARE temp_timestamp TIMESTAMP DEFAULT NULL;

	# 错误标记
	DECLARE error_status BIT DEFAULT FALSE;

	# 遍历所有有效的房间收费设置标记
	DECLARE var_done4cur_room_set INT DEFAULT FALSE;
	DECLARE cur_room_set CURSOR FOR
		#表计房间收费设置
		SELECT
			charge_set.id,
			charge_set.price,
			charge_set.charge_way,
			charge_set.billing_unit,
			charge_set.billing_cycle,
			charge_set.`precision`,
			charge_set.goldrate,
			charge_set.charge_bdate,
			charge_set.charge_edate,
			room.covered_area
		FROM
			wg_roomcharge_setup charge_set,
			wg_room_file room
		WHERE
			charge_set.room_id=room.id
		AND
			charge_set.isyesno='否'
		AND
			charge_set.charge_bdate <= curret_time
		AND
			charge_set.charge_edate >= curret_time
		AND
			charge_set.deletestatus=0
		AND
			room.deletestatus=0;

	# NOT FOUND 游标循环
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_done4cur_room_set = TRUE;

	# 忽略所有异常
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET error_status=TRUE;

	# 使用事务
	START TRANSACTION;

	OPEN cur_room_set;
	room_set_loop: LOOP
		FETCH 
			cur_room_set 
		INTO 
			s_id,
			s_price,
			s_charge_way,
			s_billing_unit,
			s_billing_cycle,
			s_precision_,
			s_goldrate,
			s_charge_bdate,
			s_charge_edate,
			s_covered_area;

		IF var_done4cur_room_set THEN
			LEAVE room_set_loop;
		END IF;

		# 查询最后一期缴费清单
		SELECT
			IF(COUNT(m1.start_date),m1.start_date,NULL),
			IF(COUNT(m1.end_date),m1.end_date,NULL),
			IF(COUNT(m1.count),m1.count,NULL),
			IF(COUNT(m1.unit_price),m1.unit_price,NULL),
			IF(COUNT(m1.override),m1.override,NULL),
			IF(COUNT(m1.amount),m1.amount,NULL),
			IF(COUNT(m1.amount_overdue),m1.amount_overdue,NULL),
			IF(COUNT(m1.amount_total),m1.amount_total,NULL)
		INTO 
				m_start_date,
				m_end_date,
				m_count,
				m_unit_price,
				m_override,
				m_amount,
				m_amount_overdue,
				m_amount_total
		FROM
			wg_charge_manifest m1
		WHERE
			m1.charge_set_id=s_id
		AND
			m1.start_date=
			(
				SELECT
					MAX(m2.start_date)
				FROM
					wg_charge_manifest m2
				WHERE
					m2.charge_set_id=s_id
			);

		# 获取本次生成的起始日期
		IF m_start_date IS NOT NULL THEN
			# 计算下一期收费的截止日期
			SET temp_timestamp = fn_charge_timecaculate(m_end_date, s_billing_unit, s_billing_cycle);
			IF temp_timestamp IS NULL OR temp_timestamp > curret_time THEN
				# 如果截止日期大于当前日期, 还不需要生成新的期数
				SET temp_timestamp = NULL;
			ELSE
				#设置起始日期
				SET temp_timestamp = m_end_date;
			END IF;
		ELSE
			#第一次生成，设置起始日期
			SET temp_timestamp = s_charge_bdate;
		END IF;

		IF temp_timestamp IS NULL THEN
			ITERATE room_set_loop;
		END IF;

		# 初始化起止日期
		SET m_start_date = temp_timestamp;
		SET m_end_date = fn_charge_timecaculate(m_start_date, s_billing_unit, s_billing_cycle);
		# 截止日期小于等于当前日期时生成
		WHILE m_end_date <= curret_time AND m_end_date <= s_charge_edate DO
			# 获取本期的表计用量,如果没有抄表,不生成本期清单
			SET	m_count = NULL;
			(
				SELECT
					IF(COUNT(m.quantity),m.quantity,NULL),
					IF(COUNT(m.id),m.id,NULL)
				INTO
					m_count,
					m_extend_charge_set_id
				FROM
					wg_meter_reading_logged m
				WHERE
					m.wg_roomcharge_setup_id=s_id
				AND
					m_start_date <= m.logged_time
				AND
					m_end_date >= m.logged_time
				ORDER BY
					m.addtime DESC
				LIMIT 1
			);

			IF m_extend_charge_set_id IS NOT NULL THEN
				SET m_override = NULL;
				SET m_unit_price = s_price;
				#计算金额
				SET m_amount = m_count * m_unit_price;
				SET m_amount_overdue = NULL;
				#应收金额
				SET m_amount_total = m_amount;
				
				# 插入记录
				INSERT INTO 
					wg_charge_manifest(
						`id`,
						`charge_set_id`,
						`start_date`,
						`end_date`,
						`count`,
						`override`,
						`unit_price`,
						`amount`,
						`amount_overdue`,
						`amount_total`,
						`extend_charge_set_id`
					)
				VALUE(
					UUID(),
					s_id,
					m_start_date,
					m_end_date,
					m_count,
					m_override,
					m_unit_price,
					m_amount,
					m_amount_overdue,
					m_amount_total,
					m_extend_charge_set_id
				);
			END IF;

			# 重置起止日期
			SET m_start_date = m_end_date;
			SET m_end_date = fn_charge_timecaculate(m_start_date, s_billing_unit, s_billing_cycle);
		END WHILE;
	END LOOP;
	CLOSE cur_room_set;

	IF error_status THEN
		ROLLBACK;
	ELSE
		COMMIT;
	END IF;
END;

