create
    definer = root@localhost procedure 游标的运用()
BEGIN
DECLARE var_name VARCHAR(100);

DECLARE done INT DEFAULT FALSE;
DECLARE cursor_name CURSOR FOR select username from t_s_user;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;


OPEN cursor_name;

WHILE done<>true DO
fetch next from cursor_name into var_name;
 if done<>1 then  
   SELECT var_name ;

  end if;  


END WHILE;
CLOSE cursor_name;

END;

