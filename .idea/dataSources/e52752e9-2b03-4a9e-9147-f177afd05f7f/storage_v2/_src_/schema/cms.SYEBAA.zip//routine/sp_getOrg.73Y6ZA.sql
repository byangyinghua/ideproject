create
    definer = root@localhost procedure sp_getOrg()
BEGIN
DECLARE rootId VARCHAR(44);
CREATE TEMPORARY TABLE IF NOT EXISTS tmpLst
(sno int primary key auto_increment,ID VARCHAR(44),depth int);
DELETE FROM tmpLst;
select id into rootId from t_s_depart where parentdepartid is null or parentdepartid='';

CALL sp_createChildLst(rootId,0);
select t_s_depart.id from tmpLst,t_s_depart,t_s_group_depart where tmpLst.ID=t_s_depart.ID and t_s_group_depart.departid=t_s_depart.id ;
-- select tmpLst.sno,tmpLst.depth,t_s_depart.* from tmpLst,t_s_depart,t_s_group_depart where tmpLst.ID=t_s_depart.ID and t_s_group_depart.departid=t_s_depart.id  order by tmpLst.sno;
END;

