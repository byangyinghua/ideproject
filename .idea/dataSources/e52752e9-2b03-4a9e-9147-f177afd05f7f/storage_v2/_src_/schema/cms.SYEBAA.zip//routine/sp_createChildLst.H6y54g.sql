create
    definer = root@localhost procedure sp_createChildLst(IN rootId varchar(44), IN nDepth int)
BEGIN
	DECLARE done INT DEFAULT 0;
	DECLARE b VARCHAR(44);
	DECLARE cur1 CURSOR FOR SELECT id FROM t_s_depart where parentdepartid=rootId;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

	insert into tmpLst values (null,rootId,nDepth);
	SET @@max_sp_recursion_depth = 10;
	OPEN cur1;

	FETCH cur1 INTO b;
	WHILE done=0 DO
		CALL sp_createChildLst(b,nDepth+1);
		FETCH cur1 INTO b;
	END WHILE;
CLOSE cur1;
END;

