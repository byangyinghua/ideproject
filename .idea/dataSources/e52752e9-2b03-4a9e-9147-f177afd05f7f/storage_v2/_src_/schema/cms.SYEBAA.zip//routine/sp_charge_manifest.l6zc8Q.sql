create
    definer = root@`%` procedure sp_charge_manifest()
BEGIN
	/*
	* 收费清单生成
	* author: 龙光磊
	* 2017-5-17
	*/
	CALL sp_charge_manifest4basic();
	CALL sp_charge_manifest4meter();
END;

